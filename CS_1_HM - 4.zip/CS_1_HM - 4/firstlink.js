// https://www.jshero.net/en/success.html

// 1
// let firstname = 'Lata'
// console.log (firstname)

// let x = 'Geeta';
// console.log(x)
// x value is Geeta

// let flower = 'rose';
// let tree = 'maple';

// let x = 'Tic';
// x = 'Tac';
// x = 'Toe';
// console.log(x)
// x value is Toe

// let x = 'Laurel';
// let y = 'Hardy';
// let z = y;
// y = x;
// x = z;
// console.log(x)
// x value is Hardy

// function hello(){
// return 'Hello world!';
// }

// function a(){
// return 'Hello a!';
// };
// function b(){
//  return 'Hello b!';
// };

// function greet(){
//     return 'Haydo!'
// }

//  let salutation = greet();

// function hello() {
//     return 'Hi!';
//   }
  
//   let x = hello();

//   console.log(x)



// function echo(input){
//     return input
// }
// let result = echo('Greta')
// let resultt = echo('CO2')

// console.log(result, resultt)

// function reply(phrase) {
//     return phrase;
//   }
  
//   let x = reply('How do you do?');

//   console.log(x)


// function greet(parameter) {
//     return 'Hello ' + parameter + '!';
//   }
//  let y = greet('ana');
//  console.log(y)



// function whereIs(name) {
//     return 'Where is ' + name + '?';
//   }
  
//   let x = whereIs('Jacky');


//   console.log(x)


// function hi(name) {
//     return 'Hi ' + name + '!';
// }
  
//   let h1 = hi('Selva');
//   let h2 = hi('Pola');
//   let x = h1 + ' ' + h2;

//   console.log(x)

// function log(value) {
//     console.log(value);
//   }



  
// function log(parameter) {
//     console.log(parameter);
//   }
//   let result = log ('Ken Thompson')

// function shout(Fire){
    
//     let result = (Fire + Fire);
//     console.log(result)
//     return result

// }

// function double(name) {
//     return name + ' and ' + name;
//   }
  
//   let x = double('Roy');

//   console.log(x)

// let charNumber = 'Ai'.length;
// console.log(charNumber)


// function length (sun){
 
//   let result = sun.length;
//   return result

//   }

//   let lenghtquantity = length("sun");

//   console.log(lenghtquantity)


// function toCase(value){

//   let toCaseChange = value;
//   let toCaseChangeup = toCaseChange.toUpperCase();
//   let toCaseChangelow = toCaseChange.toLowerCase();

//   return toCaseChangelow + "-" + toCaseChangeup;  
// }

// let result = toCase("Mthatha");
// console.log(result)



// function shortcut (value, valuetwo){
//   let amnesty0 = value.charAt(0);
//   let International0 = valuetwo.charAt(0);

//   return amnesty0 + International0;
// }

// let result = shortcut('Amnesty', 'International');
// console.log(result)


// function firstChar(value)
// {
//   let firstChar = value;
//   let firstCharf = firstChar.trim();
//   let returnfirstCharvalue = firstCharf.charAt(0);
//   return returnfirstCharvalue;

// }

// let result = firstChar(' Rosa Parks ');
// console.log(result)



// 23 String: indexOf()


// function indexOfIgnoreCase (value1, value2){

// let indexOfIgnoreCaselow1 = value1.toLowerCase();
// let indexOfIgnoreCaselow = value2.toLowerCase();
// return indexOfIgnoreCaselow1.indexOf(indexOfIgnoreCaselow);
// }

// let result = indexOfIgnoreCase("bit", "IT");
// console.log(result)

// 24
// function secondIndexOf(value, value1){
//     let secondIndexOff = value.indexOf(value1);

//     return value.indexOf(value1, secondIndexOff +1);
// }

// let result = secondIndexOf('White Rabbit', 'bit');
// console.log(result)

// 25

// function firstWord (value){
//   let firstBlank = value.indexOf(' ');
//   return value.substr(0, firstBlank);

// }
// let result = firstWord('speak again');
// console.log(result)


// 26

// function normalize(value){
//  let changevalue = value.replace(/-/gi, '/');
//  return changevalue;

// }
 
// let result = normalize('20-05-2017');
// console.log(result)


// 27 numbers

